package studentdata;

public class Student {

	 int stuid;
	 String stuname;
	public Student(int stuid, String stuname) {
		super();
		this.stuid = stuid;
		this.stuname = stuname;
	}
	public int getStuid() {
		return stuid;
	}
	public void setStuid(int stuid) {
		this.stuid = stuid;
	}
	public String getStuname() {
		return stuname;
	}
	public void setStuname(String stuname) {
		this.stuname = stuname;
	}
	@Override
	public String toString() {
		return "Student [stuid=" + stuid + ", stuname=" + stuname + "]";
	}
	
	
}
