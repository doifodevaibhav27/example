package studentdata;

import java.util.ArrayList;

public class StudentClient {
	
	public static void main(String[] args) throws Exception {
		
		ArrayList<Student> al=StudentController.getstudent();
        for (Student student : al) {
			System.out.println(student.stuid);
		    System.out.println(student.stuname);
	}
  }
}
