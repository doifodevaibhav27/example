package studentdata;

import java.util.ArrayList;

public class StudentController {
	
	static ArrayList<Student> getstudent() throws Exception{
		ArrayList<Student> alstu= StudentService.getstudent();
		return alstu;
	}

}
