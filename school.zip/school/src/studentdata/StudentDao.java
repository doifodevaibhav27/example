package studentdata;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.Statement;
import java.util.ArrayList;

public class StudentDao {
	
	static ArrayList<Student> getstudent() throws Exception{
		
		//System.out.println("1");
		Class.forName("com.mysql.jdbc.Driver");
		//System.out.println("2");
		Connection connection=DriverManager.getConnection("jdbc:mysql://localhost:3306/student", "root", "1234");
		//System.out.println("3");
		String sql="select *from student";
		//System.out.println("4");
		Statement statement=connection.createStatement();
		//System.out.println("5");
		ResultSet resultset=statement.executeQuery(sql);
		
		ArrayList<Student> alstu=new ArrayList<Student>();
		while(resultset.next()){
			
			int sid=resultset.getInt(1);
			String sname=resultset.getString(2);
			//String sage=resultset.getString(3);
			//String scity=resultset.getString(4);
			
			Student student=new Student(sid,sname);
			alstu.add(student);
			//System.out.println("ID :"+sid);
			//System.out.println("Name :"+sname);
			//System.out.println("Age :"+sage);
			//System.out.println("city :"+scity);
		}
			
	
		return alstu;
		
	}

}
