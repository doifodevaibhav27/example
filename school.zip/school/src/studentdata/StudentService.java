package studentdata;

import java.util.ArrayList;

public class StudentService {
	
	static ArrayList<Student> getstudent() throws Exception{
		
		ArrayList<Student> alstu= StudentDao.getstudent();
	
		for (Student student : alstu) {
			
			if( student.stuname.startsWith("V")){
				System.out.println(student);
				alstu.remove(student);
			}
		}
	
		
		return alstu;
	}

}
